var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  brands: () => brands,
  brandsRelations: () => brandsRelations,
  certificationTypeEnum: () => certificationTypeEnum,
  certifications: () => certifications,
  courseCertificates: () => courseCertificates,
  courseLessons: () => courseLessons,
  courseModules: () => courseModules,
  courses: () => courses,
  creators: () => creators,
  designers: () => designers,
  financialInstitutions: () => financialInstitutions,
  financingLeads: () => financingLeads,
  insertBrandSchema: () => insertBrandSchema,
  insertCertificationSchema: () => insertCertificationSchema,
  insertCourseCertificateSchema: () => insertCourseCertificateSchema,
  insertCourseLessonSchema: () => insertCourseLessonSchema,
  insertCourseModuleSchema: () => insertCourseModuleSchema,
  insertCourseSchema: () => insertCourseSchema,
  insertFinancingLeadSchema: () => insertFinancingLeadSchema,
  insertManufacturerSchema: () => insertManufacturerSchema,
  insertMessageSchema: () => insertMessageSchema,
  insertNotificationSchema: () => insertNotificationSchema,
  insertPortfolioItemSchema: () => insertPortfolioItemSchema,
  insertProjectMaterialSchema: () => insertProjectMaterialSchema,
  insertProjectSchema: () => insertProjectSchema,
  insertRawMaterialSchema: () => insertRawMaterialSchema,
  insertRawMaterialSupplierSchema: () => insertRawMaterialSupplierSchema,
  insertResourceSchema: () => insertResourceSchema,
  insertReviewSchema: () => insertReviewSchema,
  insertRfqResponseSchema: () => insertRfqResponseSchema,
  insertRfqSchema: () => insertRfqSchema,
  insertUserCourseEnrollmentSchema: () => insertUserCourseEnrollmentSchema,
  insertUserLessonProgressSchema: () => insertUserLessonProgressSchema,
  insertVerificationRequestSchema: () => insertVerificationRequestSchema,
  leadStatusEnum: () => leadStatusEnum,
  loanApplicationStatusEnum: () => loanApplicationStatusEnum,
  loanApplications: () => loanApplications,
  loanProducts: () => loanProducts,
  manufacturers: () => manufacturers,
  manufacturersRelations: () => manufacturersRelations,
  messageStatusEnum: () => messageStatusEnum,
  messages: () => messages,
  messagesRelations: () => messagesRelations,
  notifications: () => notifications,
  portfolioItems: () => portfolioItems,
  projectMaterials: () => projectMaterials,
  projectStatusEnum: () => projectStatusEnum,
  projects: () => projects,
  projectsRelations: () => projectsRelations,
  rawMaterialSuppliers: () => rawMaterialSuppliers,
  rawMaterials: () => rawMaterials,
  resources: () => resources,
  reviews: () => reviews,
  reviewsRelations: () => reviewsRelations,
  rfqResponses: () => rfqResponses,
  rfqResponsesRelations: () => rfqResponsesRelations,
  rfqStatusEnum: () => rfqStatusEnum,
  rfqs: () => rfqs,
  rfqsRelations: () => rfqsRelations,
  serviceProviders: () => serviceProviders,
  sessions: () => sessions,
  updateBrandSchema: () => updateBrandSchema,
  updateManufacturerSchema: () => updateManufacturerSchema,
  updateProjectSchema: () => updateProjectSchema,
  updateRfqSchema: () => updateRfqSchema,
  upsertUserSchema: () => upsertUserSchema,
  userCourseEnrollments: () => userCourseEnrollments,
  userLessonProgress: () => userLessonProgress,
  userRoleEnum: () => userRoleEnum,
  users: () => users,
  usersRelations: () => usersRelations,
  verificationRequests: () => verificationRequests,
  verificationStatusEnum: () => verificationStatusEnum
});
import { sql } from "drizzle-orm";
import { relations } from "drizzle-orm";
import {
  pgTable,
  varchar,
  text,
  timestamp,
  integer,
  decimal,
  boolean,
  jsonb,
  index,
  pgEnum
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
var userRoleEnum, verificationStatusEnum, projectStatusEnum, rfqStatusEnum, messageStatusEnum, leadStatusEnum, certificationTypeEnum, loanApplicationStatusEnum, sessions, users, manufacturers, brands, serviceProviders, creators, designers, financialInstitutions, loanProducts, loanApplications, projects, rfqs, rfqResponses, messages, reviews, certifications, portfolioItems, verificationRequests, financingLeads, resources, notifications, courses, courseModules, courseLessons, userCourseEnrollments, userLessonProgress, courseCertificates, rawMaterials, rawMaterialSuppliers, projectMaterials, usersRelations, manufacturersRelations, brandsRelations, projectsRelations, rfqsRelations, rfqResponsesRelations, messagesRelations, reviewsRelations, upsertUserSchema, insertManufacturerSchema, insertBrandSchema, insertProjectSchema, insertRfqSchema, insertRfqResponseSchema, insertMessageSchema, insertReviewSchema, insertCertificationSchema, insertPortfolioItemSchema, insertVerificationRequestSchema, insertFinancingLeadSchema, insertResourceSchema, insertNotificationSchema, insertCourseSchema, insertCourseModuleSchema, insertCourseLessonSchema, insertUserCourseEnrollmentSchema, insertUserLessonProgressSchema, insertCourseCertificateSchema, insertRawMaterialSchema, insertRawMaterialSupplierSchema, insertProjectMaterialSchema, updateManufacturerSchema, updateBrandSchema, updateProjectSchema, updateRfqSchema;
var init_schema = __esm({
  "shared/schema.ts"() {
    "use strict";
    userRoleEnum = pgEnum("user_role", ["brand", "manufacturer", "service_provider", "financial_institution", "creator", "designer", "admin"]);
    verificationStatusEnum = pgEnum("verification_status", ["pending", "approved", "rejected"]);
    projectStatusEnum = pgEnum("project_status", ["draft", "active", "in_progress", "completed", "cancelled"]);
    rfqStatusEnum = pgEnum("rfq_status", ["draft", "active", "reviewing", "awarded", "closed"]);
    messageStatusEnum = pgEnum("message_status", ["sent", "delivered", "read"]);
    leadStatusEnum = pgEnum("lead_status", ["new", "contacted", "qualified", "in_review", "approved", "rejected"]);
    certificationTypeEnum = pgEnum("certification_type", ["haccp", "gmp", "organic", "iso", "fda", "other"]);
    loanApplicationStatusEnum = pgEnum("loan_application_status", ["draft", "submitted", "under_review", "approved", "rejected", "disbursed"]);
    sessions = pgTable(
      "sessions",
      {
        sid: varchar("sid").primaryKey(),
        sess: jsonb("sess").notNull(),
        expire: timestamp("expire").notNull()
      },
      (table) => [index("IDX_session_expire").on(table.expire)]
    );
    users = pgTable("users", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      email: varchar("email").unique(),
      firstName: varchar("first_name"),
      lastName: varchar("last_name"),
      profileImageUrl: varchar("profile_image_url"),
      role: userRoleEnum("role"),
      currency: varchar("currency", { length: 3 }).default("USD"),
      // JMD or USD
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    });
    manufacturers = pgTable("manufacturers", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      businessName: varchar("business_name", { length: 255 }).notNull(),
      businessRegistrationNumber: varchar("business_registration_number", { length: 100 }),
      description: text("description"),
      location: varchar("location", { length: 255 }),
      address: text("address"),
      phone: varchar("phone", { length: 50 }),
      website: varchar("website", { length: 255 }),
      logoUrl: varchar("logo_url"),
      coverImageUrl: varchar("cover_image_url"),
      // Production capacity metrics
      dailyCapacity: integer("daily_capacity"),
      weeklyCapacity: integer("weekly_capacity"),
      monthlyCapacity: integer("monthly_capacity"),
      currentUtilization: decimal("current_utilization", { precision: 5, scale: 2 }),
      // percentage
      maxOrderSize: integer("max_order_size"),
      minOrderQuantity: integer("min_order_quantity"),
      productionLines: integer("production_lines"),
      workforceSize: integer("workforce_size"),
      shiftsPerDay: integer("shifts_per_day"),
      // Industries and capabilities (stored as JSON arrays)
      industries: jsonb("industries").$type().default(sql`'[]'`),
      capabilities: jsonb("capabilities").$type().default(sql`'[]'`),
      equipmentSpecs: jsonb("equipment_specs").$type(),
      // Verification
      verificationStatus: verificationStatusEnum("verification_status").default("pending"),
      verifiedAt: timestamp("verified_at"),
      isPremiumVerified: boolean("is_premium_verified").default(false),
      // Ratings
      averageRating: decimal("average_rating", { precision: 3, scale: 2 }).default("0"),
      totalReviews: integer("total_reviews").default(0),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_manufacturer_user").on(table.userId),
      index("idx_manufacturer_verification").on(table.verificationStatus),
      index("idx_manufacturer_location").on(table.location)
    ]);
    brands = pgTable("brands", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      companyName: varchar("company_name", { length: 255 }).notNull(),
      description: text("description"),
      logoUrl: varchar("logo_url"),
      industry: varchar("industry", { length: 100 }),
      productCategories: jsonb("product_categories").$type().default(sql`'[]'`),
      companySize: varchar("company_size", { length: 50 }),
      // e.g., "1-10", "11-50", "51-200"
      annualVolume: varchar("annual_volume", { length: 50 }),
      // e.g., "< $100K", "$100K-$1M"
      preferredLocations: jsonb("preferred_locations").$type().default(sql`'[]'`),
      website: varchar("website", { length: 255 }),
      phone: varchar("phone", { length: 50 }),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_brand_user").on(table.userId)
    ]);
    serviceProviders = pgTable("service_providers", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      companyName: varchar("company_name", { length: 255 }).notNull(),
      description: text("description"),
      serviceTypes: jsonb("service_types").$type().default(sql`'[]'`),
      // e.g., design, consulting, logistics
      certifications: jsonb("certifications").$type().default(sql`'[]'`),
      website: varchar("website", { length: 255 }),
      phone: varchar("phone", { length: 50 }),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_service_provider_user").on(table.userId)
    ]);
    creators = pgTable("creators", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      displayName: varchar("display_name", { length: 255 }).notNull(),
      tagline: varchar("tagline", { length: 255 }),
      // Short professional headline
      bio: text("bio"),
      profileImageUrl: varchar("profile_image_url"),
      coverImageUrl: varchar("cover_image_url"),
      // Specialties and skills
      specialties: jsonb("specialties").$type().default(sql`'[]'`),
      // e.g., video production, copywriting, social media, branding
      skills: jsonb("skills").$type().default(sql`'[]'`),
      // specific skills/tools
      contentTypes: jsonb("content_types").$type().default(sql`'[]'`),
      // e.g., blog posts, videos, podcasts, graphics
      // Service information
      servicesOffered: jsonb("services_offered").$type().default(sql`'[]'`),
      hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }),
      projectRate: decimal("project_rate", { precision: 10, scale: 2 }),
      availableForHire: boolean("available_for_hire").default(true),
      // Portfolio and experience
      portfolioItems: jsonb("portfolio_items").$type().default(sql`'[]'`),
      yearsExperience: integer("years_experience"),
      // Contact and social
      location: varchar("location", { length: 255 }),
      website: varchar("website", { length: 255 }),
      phone: varchar("phone", { length: 50 }),
      socialLinks: jsonb("social_links").$type().default(sql`'{}'`),
      // { instagram: url, linkedin: url, etc. }
      // Ratings
      averageRating: decimal("average_rating", { precision: 3, scale: 2 }).default("0"),
      totalReviews: integer("total_reviews").default(0),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_creator_user").on(table.userId),
      index("idx_creator_available").on(table.availableForHire)
    ]);
    designers = pgTable("designers", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      displayName: varchar("display_name", { length: 255 }).notNull(),
      tagline: varchar("tagline", { length: 255 }),
      // Short professional headline
      bio: text("bio"),
      profileImageUrl: varchar("profile_image_url"),
      coverImageUrl: varchar("cover_image_url"),
      // Design specialties
      designSpecialties: jsonb("design_specialties").$type().default(sql`'[]'`),
      // e.g., packaging, product, industrial, graphic, UX/UI
      softwareProficiency: jsonb("software_proficiency").$type().default(sql`'[]'`),
      // e.g., Adobe Suite, Figma, SolidWorks, AutoCAD
      designStyles: jsonb("design_styles").$type().default(sql`'[]'`),
      // e.g., minimalist, modern, vintage, eco-friendly
      // Service information
      servicesOffered: jsonb("services_offered").$type().default(sql`'[]'`),
      hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }),
      projectRate: decimal("project_rate", { precision: 10, scale: 2 }),
      availableForHire: boolean("available_for_hire").default(true),
      // Portfolio and experience
      portfolioItems: jsonb("portfolio_items").$type().default(sql`'[]'`),
      yearsExperience: integer("years_experience"),
      certifications: jsonb("certifications").$type().default(sql`'[]'`),
      // Contact and social
      location: varchar("location", { length: 255 }),
      website: varchar("website", { length: 255 }),
      phone: varchar("phone", { length: 50 }),
      socialLinks: jsonb("social_links").$type().default(sql`'{}'`),
      // { behance: url, dribbble: url, linkedin: url, etc. }
      // Ratings
      averageRating: decimal("average_rating", { precision: 3, scale: 2 }).default("0"),
      totalReviews: integer("total_reviews").default(0),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_designer_user").on(table.userId),
      index("idx_designer_available").on(table.availableForHire)
    ]);
    financialInstitutions = pgTable("financial_institutions", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      institutionName: varchar("institution_name", { length: 255 }).notNull(),
      institutionType: varchar("institution_type", { length: 100 }),
      // bank, credit union, microfinance
      description: text("description"),
      logoUrl: varchar("logo_url"),
      location: varchar("location", { length: 255 }),
      address: text("address"),
      loanProducts: jsonb("loan_products").$type().default(sql`'[]'`),
      minLoanAmount: decimal("min_loan_amount", { precision: 15, scale: 2 }),
      maxLoanAmount: decimal("max_loan_amount", { precision: 15, scale: 2 }),
      website: varchar("website", { length: 255 }),
      phone: varchar("phone", { length: 50 }),
      email: varchar("email", { length: 255 }),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_financial_institution_user").on(table.userId)
    ]);
    loanProducts = pgTable("loan_products", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      lenderId: varchar("lender_id").notNull().references(() => financialInstitutions.id, { onDelete: "cascade" }),
      productName: varchar("product_name", { length: 255 }).notNull(),
      description: text("description"),
      loanType: varchar("loan_type", { length: 100 }),
      // e.g., "working capital", "equipment financing", "expansion loan"
      minAmount: decimal("min_amount", { precision: 15, scale: 2 }).notNull(),
      maxAmount: decimal("max_amount", { precision: 15, scale: 2 }).notNull(),
      interestRateMin: decimal("interest_rate_min", { precision: 5, scale: 2 }),
      // percentage
      interestRateMax: decimal("interest_rate_max", { precision: 5, scale: 2 }),
      // percentage
      termMonthsMin: integer("term_months_min"),
      termMonthsMax: integer("term_months_max"),
      currency: varchar("currency", { length: 3 }).default("JMD"),
      requirements: jsonb("requirements").$type().default(sql`'[]'`),
      features: jsonb("features").$type().default(sql`'[]'`),
      isActive: boolean("is_active").default(true),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_loan_product_lender").on(table.lenderId),
      index("idx_loan_product_type").on(table.loanType)
    ]);
    loanApplications = pgTable("loan_applications", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      loanProductId: varchar("loan_product_id").notNull().references(() => loanProducts.id, { onDelete: "cascade" }),
      applicantId: varchar("applicant_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      businessId: varchar("business_id"),
      // Could be manufacturerId or brandId
      businessType: varchar("business_type", { length: 50 }),
      // 'manufacturer' or 'brand'
      requestedAmount: decimal("requested_amount", { precision: 15, scale: 2 }).notNull(),
      requestedTermMonths: integer("requested_term_months").notNull(),
      purpose: text("purpose").notNull(),
      businessRevenue: decimal("business_revenue", { precision: 15, scale: 2 }),
      yearsInBusiness: integer("years_in_business"),
      employeeCount: integer("employee_count"),
      collateralDescription: text("collateral_description"),
      status: loanApplicationStatusEnum("status").default("draft"),
      reviewNotes: text("review_notes"),
      approvedAmount: decimal("approved_amount", { precision: 15, scale: 2 }),
      approvedRate: decimal("approved_rate", { precision: 5, scale: 2 }),
      approvedTermMonths: integer("approved_term_months"),
      documents: jsonb("documents").$type().default(sql`'[]'`),
      submittedAt: timestamp("submitted_at"),
      reviewedAt: timestamp("reviewed_at"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_loan_application_product").on(table.loanProductId),
      index("idx_loan_application_applicant").on(table.applicantId),
      index("idx_loan_application_status").on(table.status)
    ]);
    projects = pgTable("projects", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      brandId: varchar("brand_id").notNull().references(() => brands.id, { onDelete: "cascade" }),
      manufacturerId: varchar("manufacturer_id").references(() => manufacturers.id, { onDelete: "set null" }),
      title: varchar("title", { length: 255 }).notNull(),
      description: text("description"),
      category: varchar("category", { length: 100 }),
      status: projectStatusEnum("status").default("draft"),
      budget: decimal("budget", { precision: 15, scale: 2 }),
      currency: varchar("currency", { length: 3 }).default("USD"),
      timeline: varchar("timeline", { length: 100 }),
      // e.g., "3 months"
      startDate: timestamp("start_date"),
      expectedCompletionDate: timestamp("expected_completion_date"),
      actualCompletionDate: timestamp("actual_completion_date"),
      requirements: jsonb("requirements").$type(),
      milestones: jsonb("milestones").$type().default(sql`'[]'`),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_project_brand").on(table.brandId),
      index("idx_project_manufacturer").on(table.manufacturerId),
      index("idx_project_status").on(table.status)
    ]);
    rfqs = pgTable("rfqs", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      brandId: varchar("brand_id").notNull().references(() => brands.id, { onDelete: "cascade" }),
      title: varchar("title", { length: 255 }).notNull(),
      description: text("description").notNull(),
      category: varchar("category", { length: 100 }),
      status: rfqStatusEnum("status").default("draft"),
      budget: decimal("budget", { precision: 15, scale: 2 }),
      currency: varchar("currency", { length: 3 }).default("USD"),
      quantity: integer("quantity"),
      timeline: varchar("timeline", { length: 100 }),
      requirements: jsonb("requirements").$type(),
      targetManufacturers: jsonb("target_manufacturers").$type().default(sql`'[]'`),
      attachments: jsonb("attachments").$type().default(sql`'[]'`),
      responseCount: integer("response_count").default(0),
      expiresAt: timestamp("expires_at"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_rfq_brand").on(table.brandId),
      index("idx_rfq_status").on(table.status)
    ]);
    rfqResponses = pgTable("rfq_responses", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      rfqId: varchar("rfq_id").notNull().references(() => rfqs.id, { onDelete: "cascade" }),
      manufacturerId: varchar("manufacturer_id").notNull().references(() => manufacturers.id, { onDelete: "cascade" }),
      proposedPrice: decimal("proposed_price", { precision: 15, scale: 2 }),
      currency: varchar("currency", { length: 3 }).default("USD"),
      proposedTimeline: varchar("proposed_timeline", { length: 100 }),
      message: text("message"),
      attachments: jsonb("attachments").$type().default(sql`'[]'`),
      isAwarded: boolean("is_awarded").default(false),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_rfq_response_rfq").on(table.rfqId),
      index("idx_rfq_response_manufacturer").on(table.manufacturerId)
    ]);
    messages = pgTable("messages", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      senderId: varchar("sender_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      recipientId: varchar("recipient_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      subject: varchar("subject", { length: 255 }),
      content: text("content").notNull(),
      threadId: varchar("thread_id"),
      // For grouping messages in conversations
      status: messageStatusEnum("status").default("sent"),
      attachments: jsonb("attachments").$type().default(sql`'[]'`),
      readAt: timestamp("read_at"),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_message_sender").on(table.senderId),
      index("idx_message_recipient").on(table.recipientId),
      index("idx_message_thread").on(table.threadId)
    ]);
    reviews = pgTable("reviews", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      manufacturerId: varchar("manufacturer_id").notNull().references(() => manufacturers.id, { onDelete: "cascade" }),
      projectId: varchar("project_id").references(() => projects.id, { onDelete: "set null" }),
      reviewerId: varchar("reviewer_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      rating: integer("rating").notNull(),
      // 1-5
      qualityRating: integer("quality_rating"),
      // 1-5
      communicationRating: integer("communication_rating"),
      // 1-5
      timelinessRating: integer("timeliness_rating"),
      // 1-5
      testimonial: text("testimonial"),
      response: text("response"),
      // Manufacturer's response
      respondedAt: timestamp("responded_at"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_review_manufacturer").on(table.manufacturerId),
      index("idx_review_project").on(table.projectId),
      index("idx_review_reviewer").on(table.reviewerId)
    ]);
    certifications = pgTable("certifications", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      manufacturerId: varchar("manufacturer_id").notNull().references(() => manufacturers.id, { onDelete: "cascade" }),
      certificationType: certificationTypeEnum("certification_type").notNull(),
      customType: varchar("custom_type", { length: 100 }),
      // For "other" type
      issuer: varchar("issuer", { length: 255 }).notNull(),
      issueDate: timestamp("issue_date"),
      expiryDate: timestamp("expiry_date"),
      documentUrl: varchar("document_url"),
      verificationStatus: verificationStatusEnum("verification_status").default("pending"),
      verifiedAt: timestamp("verified_at"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_certification_manufacturer").on(table.manufacturerId),
      index("idx_certification_type").on(table.certificationType)
    ]);
    portfolioItems = pgTable("portfolio_items", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      manufacturerId: varchar("manufacturer_id").notNull().references(() => manufacturers.id, { onDelete: "cascade" }),
      title: varchar("title", { length: 255 }).notNull(),
      description: text("description"),
      category: varchar("category", { length: 100 }),
      images: jsonb("images").$type().default(sql`'[]'`),
      projectDate: timestamp("project_date"),
      tags: jsonb("tags").$type().default(sql`'[]'`),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_portfolio_manufacturer").on(table.manufacturerId)
    ]);
    verificationRequests = pgTable("verification_requests", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      manufacturerId: varchar("manufacturer_id").notNull().references(() => manufacturers.id, { onDelete: "cascade" }),
      requestType: varchar("request_type", { length: 50 }).notNull(),
      // 'manual' or 'premium'
      status: verificationStatusEnum("status").default("pending"),
      documents: jsonb("documents").$type().default(sql`'[]'`),
      notes: text("notes"),
      reviewedBy: varchar("reviewed_by").references(() => users.id, { onDelete: "set null" }),
      reviewedAt: timestamp("reviewed_at"),
      reviewNotes: text("review_notes"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_verification_manufacturer").on(table.manufacturerId),
      index("idx_verification_status").on(table.status)
    ]);
    financingLeads = pgTable("financing_leads", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      applicantId: varchar("applicant_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      institutionId: varchar("institution_id").references(() => financialInstitutions.id, { onDelete: "set null" }),
      companyName: varchar("company_name", { length: 255 }).notNull(),
      loanAmount: decimal("loan_amount", { precision: 15, scale: 2 }).notNull(),
      currency: varchar("currency", { length: 3 }).default("USD"),
      loanPurpose: text("loan_purpose"),
      industry: varchar("industry", { length: 100 }),
      yearsInBusiness: integer("years_in_business"),
      annualRevenue: decimal("annual_revenue", { precision: 15, scale: 2 }),
      creditScore: varchar("credit_score", { length: 50 }),
      status: leadStatusEnum("status").default("new"),
      contactedAt: timestamp("contacted_at"),
      notes: text("notes"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_financing_lead_applicant").on(table.applicantId),
      index("idx_financing_lead_institution").on(table.institutionId),
      index("idx_financing_lead_status").on(table.status)
    ]);
    resources = pgTable("resources", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      title: varchar("title", { length: 255 }).notNull(),
      category: varchar("category", { length: 100 }).notNull(),
      // export_guides, certification_templates, costing_calculators
      description: text("description"),
      fileUrl: varchar("file_url"),
      fileType: varchar("file_type", { length: 50 }),
      // pdf, xlsx, docx
      tags: jsonb("tags").$type().default(sql`'[]'`),
      viewCount: integer("view_count").default(0),
      downloadCount: integer("download_count").default(0),
      createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_resource_category").on(table.category)
    ]);
    notifications = pgTable("notifications", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      type: varchar("type", { length: 100 }).notNull(),
      // message, rfq_response, verification_update, etc.
      title: varchar("title", { length: 255 }).notNull(),
      message: text("message"),
      actionUrl: varchar("action_url"),
      isRead: boolean("is_read").default(false),
      readAt: timestamp("read_at"),
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_notification_user").on(table.userId),
      index("idx_notification_read").on(table.isRead)
    ]);
    courses = pgTable("courses", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      title: varchar("title", { length: 255 }).notNull(),
      description: text("description"),
      category: varchar("category", { length: 100 }).notNull(),
      // manufacturing, export, compliance, quality_control
      level: varchar("level", { length: 50 }).default("beginner"),
      // beginner, intermediate, advanced
      duration: integer("duration"),
      // in minutes
      thumbnailUrl: varchar("thumbnail_url"),
      instructorName: varchar("instructor_name", { length: 255 }),
      instructorBio: text("instructor_bio"),
      isPublished: boolean("is_published").default(true),
      enrollmentCount: integer("enrollment_count").default(0),
      certificateTemplate: varchar("certificate_template"),
      createdBy: varchar("created_by").references(() => users.id, { onDelete: "set null" }),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_course_category").on(table.category),
      index("idx_course_published").on(table.isPublished)
    ]);
    courseModules = pgTable("course_modules", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      courseId: varchar("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
      title: varchar("title", { length: 255 }).notNull(),
      description: text("description"),
      orderIndex: integer("order_index").notNull().default(0),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_module_course").on(table.courseId)
    ]);
    courseLessons = pgTable("course_lessons", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      moduleId: varchar("module_id").notNull().references(() => courseModules.id, { onDelete: "cascade" }),
      title: varchar("title", { length: 255 }).notNull(),
      content: text("content"),
      // Lesson content in markdown or HTML
      videoUrl: varchar("video_url"),
      duration: integer("duration"),
      // in minutes
      orderIndex: integer("order_index").notNull().default(0),
      resourceUrls: jsonb("resource_urls").$type().default(sql`'[]'`),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_lesson_module").on(table.moduleId)
    ]);
    userCourseEnrollments = pgTable("user_course_enrollments", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      courseId: varchar("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
      enrolledAt: timestamp("enrolled_at").defaultNow(),
      completedAt: timestamp("completed_at"),
      progressPercentage: integer("progress_percentage").default(0),
      lastAccessedAt: timestamp("last_accessed_at")
    }, (table) => [
      index("idx_enrollment_user").on(table.userId),
      index("idx_enrollment_course").on(table.courseId)
    ]);
    userLessonProgress = pgTable("user_lesson_progress", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      lessonId: varchar("lesson_id").notNull().references(() => courseLessons.id, { onDelete: "cascade" }),
      isCompleted: boolean("is_completed").default(false),
      completedAt: timestamp("completed_at"),
      timeSpent: integer("time_spent").default(0),
      // in seconds
      createdAt: timestamp("created_at").defaultNow()
    }, (table) => [
      index("idx_progress_user").on(table.userId),
      index("idx_progress_lesson").on(table.lessonId)
    ]);
    courseCertificates = pgTable("course_certificates", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
      courseId: varchar("course_id").notNull().references(() => courses.id, { onDelete: "cascade" }),
      certificateUrl: varchar("certificate_url"),
      issuedAt: timestamp("issued_at").defaultNow(),
      credentialId: varchar("credential_id").unique()
      // Unique verification ID
    }, (table) => [
      index("idx_certificate_user").on(table.userId),
      index("idx_certificate_course").on(table.courseId)
    ]);
    rawMaterials = pgTable("raw_materials", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      name: varchar("name", { length: 255 }).notNull(),
      description: text("description"),
      category: varchar("category", { length: 100 }),
      // e.g., 'spices', 'fruits', 'packaging', 'chemicals'
      unitOfMeasure: varchar("unit_of_measure", { length: 50 }),
      // e.g., 'kg', 'lbs', 'liters', 'units'
      specifications: text("specifications"),
      // Technical specifications
      imageUrl: varchar("image_url"),
      minimumOrderQuantity: integer("minimum_order_quantity"),
      averagePrice: integer("average_price"),
      // in cents
      currency: varchar("currency", { length: 3 }).default("JMD"),
      supplierCount: integer("supplier_count").default(0),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_raw_material_category").on(table.category),
      index("idx_raw_material_name").on(table.name)
    ]);
    rawMaterialSuppliers = pgTable("raw_material_suppliers", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      rawMaterialId: varchar("raw_material_id").notNull().references(() => rawMaterials.id, { onDelete: "cascade" }),
      manufacturerId: varchar("manufacturer_id").notNull().references(() => manufacturers.id, { onDelete: "cascade" }),
      pricePerUnit: integer("price_per_unit"),
      // in cents
      currency: varchar("currency", { length: 3 }).default("JMD"),
      minimumOrderQuantity: integer("minimum_order_quantity"),
      leadTimeDays: integer("lead_time_days"),
      isVerified: boolean("is_verified").default(false),
      notes: text("notes"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_rms_material").on(table.rawMaterialId),
      index("idx_rms_manufacturer").on(table.manufacturerId)
    ]);
    projectMaterials = pgTable("project_materials", {
      id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
      projectId: varchar("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
      rawMaterialId: varchar("raw_material_id").notNull().references(() => rawMaterials.id, { onDelete: "cascade" }),
      supplierId: varchar("supplier_id").references(() => rawMaterialSuppliers.id, { onDelete: "set null" }),
      // Optional: specific supplier chosen
      quantity: integer("quantity").notNull(),
      unitPrice: integer("unit_price"),
      // in cents - price at time of adding
      currency: varchar("currency", { length: 3 }).default("JMD"),
      totalCost: integer("total_cost"),
      // quantity * unitPrice
      notes: text("notes"),
      createdAt: timestamp("created_at").defaultNow(),
      updatedAt: timestamp("updated_at").defaultNow()
    }, (table) => [
      index("idx_pm_project").on(table.projectId),
      index("idx_pm_material").on(table.rawMaterialId)
    ]);
    usersRelations = relations(users, ({ one, many }) => ({
      manufacturer: one(manufacturers, {
        fields: [users.id],
        references: [manufacturers.userId]
      }),
      brand: one(brands, {
        fields: [users.id],
        references: [brands.userId]
      }),
      serviceProvider: one(serviceProviders, {
        fields: [users.id],
        references: [serviceProviders.userId]
      }),
      financialInstitution: one(financialInstitutions, {
        fields: [users.id],
        references: [financialInstitutions.userId]
      }),
      sentMessages: many(messages, { relationName: "sender" }),
      receivedMessages: many(messages, { relationName: "recipient" }),
      reviews: many(reviews),
      notifications: many(notifications)
    }));
    manufacturersRelations = relations(manufacturers, ({ one, many }) => ({
      user: one(users, {
        fields: [manufacturers.userId],
        references: [users.id]
      }),
      projects: many(projects),
      certifications: many(certifications),
      portfolioItems: many(portfolioItems),
      reviews: many(reviews),
      verificationRequests: many(verificationRequests),
      rfqResponses: many(rfqResponses)
    }));
    brandsRelations = relations(brands, ({ one, many }) => ({
      user: one(users, {
        fields: [brands.userId],
        references: [users.id]
      }),
      projects: many(projects),
      rfqs: many(rfqs)
    }));
    projectsRelations = relations(projects, ({ one }) => ({
      brand: one(brands, {
        fields: [projects.brandId],
        references: [brands.id]
      }),
      manufacturer: one(manufacturers, {
        fields: [projects.manufacturerId],
        references: [manufacturers.id]
      })
    }));
    rfqsRelations = relations(rfqs, ({ one, many }) => ({
      brand: one(brands, {
        fields: [rfqs.brandId],
        references: [brands.id]
      }),
      responses: many(rfqResponses)
    }));
    rfqResponsesRelations = relations(rfqResponses, ({ one }) => ({
      rfq: one(rfqs, {
        fields: [rfqResponses.rfqId],
        references: [rfqs.id]
      }),
      manufacturer: one(manufacturers, {
        fields: [rfqResponses.manufacturerId],
        references: [manufacturers.id]
      })
    }));
    messagesRelations = relations(messages, ({ one }) => ({
      sender: one(users, {
        fields: [messages.senderId],
        references: [users.id],
        relationName: "sender"
      }),
      recipient: one(users, {
        fields: [messages.recipientId],
        references: [users.id],
        relationName: "recipient"
      })
    }));
    reviewsRelations = relations(reviews, ({ one }) => ({
      manufacturer: one(manufacturers, {
        fields: [reviews.manufacturerId],
        references: [manufacturers.id]
      }),
      project: one(projects, {
        fields: [reviews.projectId],
        references: [projects.id]
      }),
      reviewer: one(users, {
        fields: [reviews.reviewerId],
        references: [users.id]
      })
    }));
    upsertUserSchema = createInsertSchema(users).pick({
      id: true,
      email: true,
      firstName: true,
      lastName: true,
      profileImageUrl: true,
      role: true,
      currency: true
    });
    insertManufacturerSchema = createInsertSchema(manufacturers).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      verifiedAt: true,
      averageRating: true,
      totalReviews: true
    });
    insertBrandSchema = createInsertSchema(brands).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertProjectSchema = createInsertSchema(projects).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertRfqSchema = createInsertSchema(rfqs).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      responseCount: true
    });
    insertRfqResponseSchema = createInsertSchema(rfqResponses).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      isAwarded: true
    });
    insertMessageSchema = createInsertSchema(messages).omit({
      id: true,
      createdAt: true,
      readAt: true
    });
    insertReviewSchema = createInsertSchema(reviews).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      respondedAt: true
    });
    insertCertificationSchema = createInsertSchema(certifications).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      verifiedAt: true
    });
    insertPortfolioItemSchema = createInsertSchema(portfolioItems).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertVerificationRequestSchema = createInsertSchema(verificationRequests).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      reviewedBy: true,
      reviewedAt: true,
      reviewNotes: true
    });
    insertFinancingLeadSchema = createInsertSchema(financingLeads).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      contactedAt: true
    });
    insertResourceSchema = createInsertSchema(resources).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      viewCount: true,
      downloadCount: true
    });
    insertNotificationSchema = createInsertSchema(notifications).omit({
      id: true,
      createdAt: true,
      readAt: true
    });
    insertCourseSchema = createInsertSchema(courses).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      enrollmentCount: true
    });
    insertCourseModuleSchema = createInsertSchema(courseModules).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertCourseLessonSchema = createInsertSchema(courseLessons).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertUserCourseEnrollmentSchema = createInsertSchema(userCourseEnrollments).omit({
      id: true,
      enrolledAt: true,
      completedAt: true,
      lastAccessedAt: true
    });
    insertUserLessonProgressSchema = createInsertSchema(userLessonProgress).omit({
      id: true,
      createdAt: true,
      completedAt: true
    });
    insertCourseCertificateSchema = createInsertSchema(courseCertificates).omit({
      id: true,
      issuedAt: true
    });
    insertRawMaterialSchema = createInsertSchema(rawMaterials).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      supplierCount: true
    });
    insertRawMaterialSupplierSchema = createInsertSchema(rawMaterialSuppliers).omit({
      id: true,
      createdAt: true,
      updatedAt: true
    });
    insertProjectMaterialSchema = createInsertSchema(projectMaterials).omit({
      id: true,
      createdAt: true,
      updatedAt: true,
      totalCost: true
      // Will be calculated automatically
    });
    updateManufacturerSchema = insertManufacturerSchema.omit({
      userId: true,
      verificationStatus: true,
      isPremiumVerified: true
    });
    updateBrandSchema = insertBrandSchema.omit({
      userId: true
    });
    updateProjectSchema = insertProjectSchema.omit({
      brandId: true,
      manufacturerId: true
    });
    updateRfqSchema = insertRfqSchema.omit({
      brandId: true
    });
  }
});

// server/db.ts
var db_exports = {};
__export(db_exports, {
  db: () => db
});
import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
var Pool, ca, forceSslEnv, urlHasSslRequire, enableSsl, max, idleTimeoutMillis, connectionTimeoutMillis, pool, db;
var init_db = __esm({
  "server/db.ts"() {
    "use strict";
    init_schema();
    ({ Pool } = pg);
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "DATABASE_URL must be set. Did you forget to provision a database?"
      );
    }
    ca = process.env.DATABASE_SSL_CA ? process.env.DATABASE_SSL_CA.replace(/\\n/g, "\n") : void 0;
    forceSslEnv = process.env.PG_SSL === "true" || process.env.DATABASE_SSL === "true";
    urlHasSslRequire = (() => {
      const url = process.env.DATABASE_URL ?? "";
      return /sslmode=(require|verify-full|verify-ca)/i.test(url);
    })();
    enableSsl = !!ca || forceSslEnv || urlHasSslRequire;
    max = process.env.PGPOOL_MAX ? Number(process.env.PGPOOL_MAX) : 10;
    idleTimeoutMillis = process.env.PG_IDLE_TIMEOUT_MS ? Number(process.env.PG_IDLE_TIMEOUT_MS) : 3e4;
    connectionTimeoutMillis = process.env.PG_CONN_TIMEOUT_MS ? Number(process.env.PG_CONN_TIMEOUT_MS) : 5e3;
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ...enableSsl ? {
        ssl: ca ? { ca, rejectUnauthorized: true } : { rejectUnauthorized: false }
      } : {},
      max,
      idleTimeoutMillis,
      connectionTimeoutMillis
    });
    db = drizzle(pool, { schema: schema_exports });
  }
});

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/memoryStorage.ts
import { randomUUID } from "crypto";
var MemoryStorage = class {
  users = [];
  manufacturers = [];
  brands = [];
  projects = [];
  rfqs = [];
  rfqResponses = [];
  messages = [];
  reviews = [];
  certifications = [];
  portfolioItems = [];
  verificationRequests = [];
  financingLeads = [];
  resources = [];
  notifications = [];
  courses = [];
  courseModules = [];
  courseLessons = [];
  enrollments = [];
  lessonProgress = [];
  rawMaterials = [];
  rawMaterialSuppliers = [];
  projectMaterials = [];
  financialInstitutions = [];
  loanProducts = [];
  loanApplications = [];
  // Helpers
  now() {
    return /* @__PURE__ */ new Date();
  }
  assignId(obj) {
    return { ...obj, id: obj.id || randomUUID() };
  }
  // Users
  async getUser(id) {
    return this.users.find((u) => u.id === id);
  }
  async upsertUser(userData) {
    const existing = this.users.find((u) => u.id === userData.id);
    if (existing) {
      const updated = { ...existing, ...userData, updatedAt: this.now() };
      this.users = this.users.map((u) => u.id === existing.id ? updated : u);
      return updated;
    }
    const created = {
      id: userData.id,
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      profileImageUrl: userData.profileImageUrl,
      role: userData.role,
      currency: userData.currency || "USD",
      createdAt: this.now(),
      updatedAt: this.now()
    };
    this.users.push(created);
    return created;
  }
  async getUsersByRole(role) {
    return this.users.filter((u) => u.role === role);
  }
  // Manufacturers
  async getManufacturer(id) {
    return this.manufacturers.find((m) => m.id === id);
  }
  async getManufacturerByUserId(userId) {
    return this.manufacturers.find((m) => m.userId === userId);
  }
  async createManufacturer(data) {
    const withId = this.assignId(data);
    const manufacturer = {
      ...withId,
      verificationStatus: data.verificationStatus || "pending",
      averageRating: data.averageRating || 0,
      totalReviews: data.totalReviews || 0,
      createdAt: this.now(),
      updatedAt: this.now()
    };
    this.manufacturers.push(manufacturer);
    return manufacturer;
  }
  async updateManufacturer(id, data) {
    const existing = this.manufacturers.find((m) => m.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this.manufacturers = this.manufacturers.map((m) => m.id === id ? updated : m);
    return updated;
  }
  async searchManufacturers(_filters) {
    return this.manufacturers;
  }
  // Brands
  async getBrand(id) {
    return this.brands.find((b) => b.id === id);
  }
  async getBrandByUserId(userId) {
    return this.brands.find((b) => b.userId === userId);
  }
  async createBrand(data) {
    const withId = this.assignId(data);
    const brand = {
      ...withId,
      createdAt: this.now(),
      updatedAt: this.now()
    };
    this.brands.push(brand);
    return brand;
  }
  async updateBrand(id, data) {
    const existing = this.brands.find((b) => b.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this.brands = this.brands.map((b) => b.id === id ? updated : b);
    return updated;
  }
  // Projects
  async getProject(id) {
    return this.projects.find((p) => p.id === id);
  }
  async getProjectsByBrand(brandId) {
    return this.projects.filter((p) => p.brandId === brandId);
  }
  async getProjectsByManufacturer(manufacturerId) {
    return this.projects.filter((p) => p.manufacturerId === manufacturerId);
  }
  async createProject(data) {
    const withId = this.assignId(data);
    const project = {
      ...withId,
      status: data.status || "draft",
      createdAt: this.now(),
      updatedAt: this.now()
    };
    this.projects.push(project);
    return project;
  }
  async updateProject(id, data) {
    const existing = this.projects.find((p) => p.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this.projects = this.projects.map((p) => p.id === id ? updated : p);
    return updated;
  }
  // RFQs
  async getRfq(id) {
    return this.rfqs.find((r) => r.id === id);
  }
  async getRfqsByBrand(brandId) {
    return this.rfqs.filter((r) => r.brandId === brandId);
  }
  async getActiveRfqs() {
    return this.rfqs.filter((r) => r.status !== "closed");
  }
  async createRfq(data) {
    const withId = this.assignId(data);
    const rfq = {
      ...withId,
      status: data.status || "active",
      createdAt: this.now(),
      updatedAt: this.now()
    };
    this.rfqs.push(rfq);
    return rfq;
  }
  async updateRfq(id, data) {
    const existing = this.rfqs.find((r) => r.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this.rfqs = this.rfqs.map((r) => r.id === id ? updated : r);
    return updated;
  }
  async deleteRfq(id) {
    const before = this.rfqs.length;
    this.rfqs = this.rfqs.filter((r) => r.id !== id);
    return this.rfqs.length < before;
  }
  // RFQ Responses
  async getRfqResponse(id) {
    return this.rfqResponses.find((rr) => rr.id === id);
  }
  async getRfqResponsesByRfq(rfqId) {
    return this.rfqResponses.filter((rr) => rr.rfqId === rfqId);
  }
  async getRfqResponsesByManufacturer(manufacturerId) {
    return this.rfqResponses.filter((rr) => rr.manufacturerId === manufacturerId);
  }
  async createRfqResponse(data) {
    const withId = this.assignId(data);
    const response = {
      ...withId,
      createdAt: this.now(),
      updatedAt: this.now()
    };
    this.rfqResponses.push(response);
    return response;
  }
  // Messages
  async getMessage(id) {
    return this.messages.find((m) => m.id === id);
  }
  async getMessagesBetweenUsers(userId1, userId2) {
    return this.messages.filter((m) => m.senderId === userId1 && m.recipientId === userId2 || m.senderId === userId2 && m.recipientId === userId1);
  }
  async getMessageThreads(userId) {
    return this.messages.filter((m) => m.senderId === userId || m.recipientId === userId);
  }
  async createMessage(data) {
    const withId = this.assignId(data);
    const message = { ...withId, createdAt: this.now(), updatedAt: this.now(), status: data.status || "sent" };
    this.messages.push(message);
    return message;
  }
  async markMessageAsRead(id) {
    const existing = this.messages.find((m) => m.id === id);
    if (!existing) return false;
    const updated = { ...existing, status: "read", updatedAt: this.now() };
    this.messages = this.messages.map((m) => m.id === id ? updated : m);
    return true;
  }
  // Reviews
  async getReview(id) {
    return this.reviews.find((r) => r.id === id);
  }
  async getReviewsByManufacturer(manufacturerId) {
    return this.reviews.filter((r) => r.manufacturerId === manufacturerId);
  }
  async createReview(data) {
    const withId = this.assignId(data);
    const review = { ...withId, createdAt: this.now(), updatedAt: this.now() };
    this.reviews.push(review);
    return review;
  }
  async updateReviewResponse(id, response) {
    const existing = this.reviews.find((r) => r.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, response, updatedAt: this.now() };
    this.reviews = this.reviews.map((r) => r.id === id ? updated : r);
    return updated;
  }
  // Certifications
  async getCertificationsByManufacturer(manufacturerId) {
    return this.certifications.filter((c) => c.manufacturerId === manufacturerId);
  }
  async createCertification(data) {
    const withId = this.assignId(data);
    const cert = { ...withId, createdAt: this.now(), updatedAt: this.now() };
    this.certifications.push(cert);
    return cert;
  }
  async verifyCertification(id) {
    const existing = this.certifications.find((c) => c.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, verifiedAt: this.now() };
    this.certifications = this.certifications.map((c) => c.id === id ? updated : c);
    return updated;
  }
  // Portfolio
  async getPortfolioItemsByManufacturer(manufacturerId) {
    return this.portfolioItems.filter((p) => p.manufacturerId === manufacturerId);
  }
  async createPortfolioItem(data) {
    const withId = this.assignId(data);
    const item = { ...withId, createdAt: this.now(), updatedAt: this.now() };
    this.portfolioItems.push(item);
    return item;
  }
  // Verification Requests
  async getVerificationRequest(id) {
    return this.verificationRequests.find((v) => v.id === id);
  }
  async getPendingVerifications() {
    return this.verificationRequests.filter((v) => v.status === "pending");
  }
  async createVerificationRequest(data) {
    const withId = this.assignId(data);
    const req = { ...withId, createdAt: this.now(), updatedAt: this.now(), status: data.status || "pending" };
    this.verificationRequests.push(req);
    return req;
  }
  async updateVerificationStatus(id, status, reviewedBy, notes) {
    const existing = this.verificationRequests.find((v) => v.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, status, reviewedBy, notes, updatedAt: this.now() };
    this.verificationRequests = this.verificationRequests.map((v) => v.id === id ? updated : v);
    return updated;
  }
  // Financing Leads
  async getFinancingLead(id) {
    return this.financingLeads.find((f) => f.id === id);
  }
  async getFinancingLeadsByInstitution(institutionId) {
    return this.financingLeads.filter((f) => f.institutionId === institutionId);
  }
  async createFinancingLead(data) {
    const withId = this.assignId(data);
    const lead = { ...withId, createdAt: this.now(), updatedAt: this.now(), status: data.status || "new" };
    this.financingLeads.push(lead);
    return lead;
  }
  async updateFinancingLeadStatus(id, status) {
    const existing = this.financingLeads.find((f) => f.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, status, updatedAt: this.now() };
    this.financingLeads = this.financingLeads.map((f) => f.id === id ? updated : f);
    return updated;
  }
  // Resources
  async getResources() {
    return this.resources;
  }
  async getResourcesByCategory(category) {
    return this.resources.filter((r) => r.category === category);
  }
  async incrementResourceView(id) {
    const existing = this.resources.find((r) => r.id === id);
    if (!existing) return false;
    existing.views = (existing.views || 0) + 1;
    return true;
  }
  async incrementResourceDownload(id) {
    const existing = this.resources.find((r) => r.id === id);
    if (!existing) return false;
    existing.downloads = (existing.downloads || 0) + 1;
    return true;
  }
  // Notifications
  async getNotificationsByUser(userId) {
    return this.notifications.filter((n) => n.userId === userId);
  }
  async createNotification(data) {
    const withId = this.assignId(data);
    const notif = { ...withId, createdAt: this.now(), updatedAt: this.now(), isRead: data.isRead || false };
    this.notifications.push(notif);
    return notif;
  }
  async markNotificationAsRead(id) {
    const existing = this.notifications.find((n) => n.id === id);
    if (!existing) return false;
    const updated = { ...existing, isRead: true, updatedAt: this.now() };
    this.notifications = this.notifications.map((n) => n.id === id ? updated : n);
    return true;
  }
  // LMS (minimal stubs)
  async getCourses(_category) {
    return this.courses;
  }
  async getCourseWithModulesAndLessons(_courseId) {
    return null;
  }
  async enrollInCourse(userId, courseId) {
    const enrollment = { id: randomUUID(), userId, courseId, enrolledAt: this.now() };
    this.enrollments.push(enrollment);
    return enrollment;
  }
  async getCourseProgress(_userId, _courseId) {
    return { progressPercentage: 0, completedLessons: 0, totalLessons: 0 };
  }
  async markLessonComplete(userId, lessonId) {
    const progress = { id: randomUUID(), userId, lessonId, isCompleted: true, createdAt: this.now(), completedAt: this.now() };
    this.lessonProgress.push(progress);
    return progress;
  }
  async getUserEnrollments(userId) {
    return this.enrollments.filter((e) => e.userId === userId);
  }
  // Raw materials and project materials (minimal)
  async getRawMaterials(_category) {
    return this.rawMaterials;
  }
  async getRawMaterial(id) {
    return this.rawMaterials.find((r) => r.id === id);
  }
  async getRawMaterialSuppliers(materialId) {
    return this.rawMaterialSuppliers.filter((s) => s.rawMaterialId === materialId);
  }
  async createRawMaterial(data) {
    const withId = this.assignId(data);
    const rm = { ...withId, createdAt: this.now(), updatedAt: this.now() };
    this.rawMaterials.push(rm);
    return rm;
  }
  async createRawMaterialSupplier(data) {
    const withId = this.assignId(data);
    const s = { ...withId, createdAt: this.now(), updatedAt: this.now() };
    this.rawMaterialSuppliers.push(s);
    return s;
  }
  async getProjectMaterials(projectId) {
    return this.projectMaterials.filter((pm) => pm.projectId === projectId);
  }
  async addMaterialToProject(data) {
    const withId = this.assignId(data);
    const pm = { ...withId, createdAt: this.now(), updatedAt: this.now(), totalCost: data.totalCost || 0 };
    this.projectMaterials.push(pm);
    return pm;
  }
  async removeMaterialFromProject(id) {
    const before = this.projectMaterials.length;
    this.projectMaterials = this.projectMaterials.filter((pm) => pm.id !== id);
    return this.projectMaterials.length < before;
  }
  async updateProjectMaterialQuantity(id, quantity) {
    const existing = this.projectMaterials.find((pm) => pm.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, quantity, updatedAt: this.now() };
    this.projectMaterials = this.projectMaterials.map((pm) => pm.id === id ? updated : pm);
    return updated;
  }
  async getProjectMaterialsCost(projectId) {
    const items = this.projectMaterials.filter((pm) => pm.projectId === projectId);
    const total = items.reduce((sum, pm) => sum + (pm.totalCost || 0), 0);
    return { totalCost: total, currency: "USD" };
  }
  // Creators
  async getCreators(filters) {
    if (!filters || filters.availableForHire === void 0) return this.candidates(this.creatorsData());
    return this.candidates(this.creatorsData().filter((c) => c.availableForHire === filters.availableForHire));
  }
  async getCreator(id) {
    return this.creatorsData().find((c) => c.id === id);
  }
  async getCreatorByUserId(userId) {
    return this.creatorsData().find((c) => c.userId === userId);
  }
  async createCreator(data) {
    const created = { id: randomUUID(), createdAt: this.now(), updatedAt: this.now(), ...data };
    this._creators.push(created);
    return created;
  }
  async updateCreator(id, data) {
    const existing = this._creators.find((c) => c.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this._creators = this._creators.map((c) => c.id === id ? updated : c);
    return updated;
  }
  // Designers
  async getDesigners(filters) {
    if (!filters || filters.availableForHire === void 0) return this.candidates(this.designersData());
    return this.candidates(this.designersData().filter((d) => d.availableForHire === filters.availableForHire));
  }
  async getDesigner(id) {
    return this.designersData().find((d) => d.id === id);
  }
  async getDesignerByUserId(userId) {
    return this.designersData().find((d) => d.userId === userId);
  }
  async createDesigner(data) {
    const created = { id: randomUUID(), createdAt: this.now(), updatedAt: this.now(), ...data };
    this._designers.push(created);
    return created;
  }
  async updateDesigner(id, data) {
    const existing = this._designers.find((d) => d.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this._designers = this._designers.map((d) => d.id === id ? updated : d);
    return updated;
  }
  // Financial Institutions & Loans (minimal)
  async getFinancialInstitutions() {
    return this.financialInstitutions;
  }
  async getFinancialInstitution(id) {
    return this.financialInstitutions.find((fi) => fi.id === id);
  }
  async createFinancialInstitution(data) {
    const withId = this.assignId(data);
    const fi = { ...withId, createdAt: this.now(), updatedAt: this.now() };
    this.financialInstitutions.push(fi);
    return fi;
  }
  async updateFinancialInstitution(id, data) {
    const existing = this.financialInstitutions.find((fi) => fi.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this.financialInstitutions = this.financialInstitutions.map((fi) => fi.id === id ? updated : fi);
    return updated;
  }
  async getLoanProducts() {
    return this.loanProducts;
  }
  async getLoanProductsByInstitution(institutionId) {
    return this.loanProducts.filter((lp) => lp.lenderId === institutionId);
  }
  async createLoanProduct(data) {
    const withId = this.assignId(data);
    const lp = { ...withId, createdAt: this.now(), updatedAt: this.now(), isActive: data.isActive ?? true };
    this.loanProducts.push(lp);
    return lp;
  }
  async updateLoanProduct(id, data) {
    const existing = this.loanProducts.find((lp) => lp.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, ...data, updatedAt: this.now() };
    this.loanProducts = this.loanProducts.map((lp) => lp.id === id ? updated : lp);
    return updated;
  }
  async getLoanApplication(id) {
    return this.loanApplications.find((la) => la.id === id);
  }
  async getLoanApplicationsByApplicant(applicantId) {
    return this.loanApplications.filter((la) => la.applicantId === applicantId);
  }
  async getLoanApplicationsByInstitution(institutionId) {
    return this.loanApplications.filter((la) => la.institutionId === institutionId);
  }
  async createLoanApplication(data) {
    const withId = this.assignId(data);
    const la = { ...withId, createdAt: this.now(), updatedAt: this.now(), status: data.status || "draft" };
    this.loanApplications.push(la);
    return la;
  }
  async updateLoanApplicationStatus(id, status) {
    const existing = this.loanApplications.find((la) => la.id === id);
    if (!existing) return void 0;
    const updated = { ...existing, status, updatedAt: this.now() };
    this.loanApplications = this.loanApplications.map((la) => la.id === id ? updated : la);
    return updated;
  }
  // Internal seed for creators/designers when none exist (simple placeholders)
  _creators = [];
  _designers = [];
  creatorsData() {
    return this._creators;
  }
  designersData() {
    return this._designers;
  }
  candidates(arr) {
    return arr;
  }
};

// server/dbStorage.ts
import { eq } from "drizzle-orm";
init_schema();
var DbStorage = class extends MemoryStorage {
  // Users
  async getUser(id) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const rows = await db2.select().from(users).where(eq(users.id, id)).limit(1);
    return rows[0];
  }
  async getUsersByRole(role) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const rows = await db2.select().from(users).where(eq(users.role, role));
    return rows;
  }
  async upsertUser(data) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const result = await db2.insert(users).values(data).onConflictDoUpdate({ target: users.id, set: {
      email: data.email ?? void 0,
      firstName: data.firstName ?? void 0,
      lastName: data.lastName ?? void 0,
      profileImageUrl: data.profileImageUrl ?? void 0,
      role: data.role ?? void 0,
      currency: data.currency ?? void 0
    } }).returning();
    return result[0];
  }
  // Brands
  async getBrand(id) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const rows = await db2.select().from(brands).where(eq(brands.id, id)).limit(1);
    return rows[0];
  }
  async getBrandByUserId(userId) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const rows = await db2.select().from(brands).where(eq(brands.userId, userId)).limit(1);
    return rows[0];
  }
  async createBrand(data) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const result = await db2.insert(brands).values(data).returning();
    return result[0];
  }
  async updateBrand(id, data) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const result = await db2.update(brands).set(data).where(eq(brands.id, id)).returning();
    return result[0];
  }
  // Loans
  async createLoanApplication(data) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const res = await db2.insert(loanApplications).values(data).returning();
    return res[0];
  }
  async getLoanApplicationsByApplicant(applicantId) {
    const { db: db2 } = await Promise.resolve().then(() => (init_db(), db_exports));
    const rows = await db2.select().from(loanApplications).where(eq(loanApplications.applicantId, applicantId));
    return rows;
  }
};

// server/storage.ts
var instance = null;
function getStorage() {
  if (!instance) {
    if (process.env.DATABASE_URL) {
      instance = new DbStorage();
    } else {
      instance = new MemoryStorage();
    }
  }
  return instance;
}
var storage = getStorage();

// server/replitAuth.ts
import passport from "passport";
import session from "express-session";
import { Strategy as LocalStrategy } from "passport-local";
import MemoryStoreFactory from "memorystore";
import * as openid from "openid-client";
import connectPgSimple from "connect-pg-simple";
function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1e3;
  const MemoryStore = MemoryStoreFactory(session);
  const isProd = process.env.NODE_ENV === "production";
  const hasDb = !!process.env.DATABASE_URL;
  let sessionStore;
  if (isProd && hasDb) {
    const PgStore = connectPgSimple(session);
    sessionStore = new PgStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true,
      tableName: "session"
    });
  } else {
    sessionStore = new MemoryStore({
      checkPeriod: sessionTtl
    });
  }
  return session({
    secret: process.env.SESSION_SECRET || "dev-session-secret",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: sessionTtl
    }
  });
}
function createUserSession({
  id,
  email,
  firstName,
  lastName,
  profileImageUrl
}) {
  const expSeconds = Math.floor(Date.now() / 1e3) + 30 * 24 * 60 * 60;
  return {
    claims: {
      sub: id,
      email,
      first_name: firstName,
      last_name: lastName,
      profile_image_url: profileImageUrl,
      exp: expSeconds
    },
    expires_at: expSeconds
  };
}
function getBaseUrl(req) {
  const proto = req.headers["x-forwarded-proto"] || req.protocol || "http";
  const host = req.headers["x-forwarded-host"] || req.get("host");
  return `${proto}://${host}`;
}
async function setupAuth(app2) {
  app2.set("trust proxy", 1);
  app2.use(getSession());
  app2.use(passport.initialize());
  app2.use(passport.session());
  await storage.upsertUser({
    id: "admin",
    email: "admin@example.com",
    firstName: "Admin",
    lastName: "Demo",
    role: "brand",
    currency: "USD"
  });
  passport.use(
    new LocalStrategy(
      { usernameField: "username", passwordField: "password", passReqToCallback: true },
      async (req, username, _password, done) => {
        try {
          const role = req.body?.role || "brand";
          const id = username || `user-${Math.random().toString(36).slice(2)}`;
          const userRecord = await storage.upsertUser({
            id,
            email: req.body?.email,
            firstName: req.body?.firstName || username,
            lastName: req.body?.lastName,
            profileImageUrl: req.body?.profileImageUrl,
            role
          });
          const user = createUserSession({
            id: userRecord.id,
            email: userRecord.email || req.body?.email,
            firstName: userRecord.firstName,
            lastName: userRecord.lastName,
            profileImageUrl: userRecord.profileImageUrl
          });
          return done(null, user);
        } catch (err) {
          return done(err);
        }
      }
    )
  );
  passport.serializeUser((user, cb) => cb(null, user));
  passport.deserializeUser((user, cb) => cb(null, user));
  app2.get("/api/login", (req, res) => {
    res.status(200).json({
      message: "Use POST /api/login with { username, password, role } to sign in locally."
    });
  });
  app2.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: "Invalid credentials" });
      req.logIn(user, (err2) => {
        if (err2) return next(err2);
        return res.json({ success: true });
      });
    })(req, res, next);
  });
  app2.get("/api/logout", (req, res) => {
    req.logout(() => {
      res.redirect("/");
    });
  });
  app2.get("/api/auth/google", async (req, res, next) => {
    try {
      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      if (!clientId || !clientSecret) {
        return res.status(501).json({
          message: "Google authentication not configured.",
          hint: "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in environment."
        });
      }
      const googleIssuer = await openid.Issuer.discover("https://accounts.google.com");
      const redirectUri = `${getBaseUrl(req)}/api/auth/google/callback`;
      const client = new googleIssuer.Client({
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uris: [redirectUri],
        response_types: ["code"]
      });
      const codeVerifier = openid.generators.codeVerifier();
      const codeChallenge = openid.generators.codeChallenge(codeVerifier);
      req.session.codeVerifier = codeVerifier;
      const authUrl = client.authorizationUrl({
        scope: "openid email profile",
        code_challenge: codeChallenge,
        code_challenge_method: "S256",
        prompt: "consent"
      });
      res.redirect(authUrl);
    } catch (err) {
      next(err);
    }
  });
  app2.get("/api/auth/google/callback", async (req, res, next) => {
    try {
      const clientId = process.env.GOOGLE_CLIENT_ID;
      const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
      if (!clientId || !clientSecret) {
        return res.status(501).json({ message: "Google authentication not configured." });
      }
      const googleIssuer = await openid.Issuer.discover("https://accounts.google.com");
      const redirectUri = `${getBaseUrl(req)}/api/auth/google/callback`;
      const client = new googleIssuer.Client({
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uris: [redirectUri],
        response_types: ["code"]
      });
      const params = client.callbackParams(req);
      const tokenSet = await client.callback(redirectUri, params, {
        code_verifier: req.session.codeVerifier
      });
      const userinfo = await client.userinfo(tokenSet);
      const id = `google-${userinfo.sub}`;
      const role = "brand";
      const userRecord = await storage.upsertUser({
        id,
        email: userinfo.email,
        firstName: userinfo.given_name || "Google User",
        lastName: userinfo.family_name,
        profileImageUrl: userinfo.picture,
        role
      });
      const user = createUserSession({
        id: userRecord.id,
        email: userRecord.email,
        firstName: userRecord.firstName,
        lastName: userRecord.lastName,
        profileImageUrl: userRecord.profileImageUrl
      });
      req.logIn(user, (err) => {
        if (err) return next(err);
        res.redirect("/");
      });
    } catch (err) {
      next(err);
    }
  });
}
var isAuthenticated = async (req, res, next) => {
  const user = req.user;
  if (!req.isAuthenticated() || !user?.claims?.sub) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  return next();
};

// server/middleware/authorization.ts
var requireRole = (allowedRoles) => {
  return async (req, res, next) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const user = await storage.getUser(userId);
      if (!user || !user.role) {
        return res.status(403).json({ message: "Access denied: No role assigned" });
      }
      if (!allowedRoles.includes(user.role)) {
        return res.status(403).json({ message: "Access denied: Insufficient permissions" });
      }
      req.authenticatedUser = user;
      next();
    } catch (error) {
      console.error("Error checking role:", error);
      res.status(500).json({ message: "Failed to authorize request" });
    }
  };
};
var requireOwnership = (getOwnerId) => {
  return async (req, res, next) => {
    try {
      const userId = req.user?.claims?.sub;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const ownerId = await getOwnerId(req);
      if (!ownerId) {
        return res.status(404).json({ message: "Resource not found" });
      }
      const user = await storage.getUser(userId);
      if (user?.role === "admin") {
        req.authenticatedUser = user;
        return next();
      }
      if (ownerId !== userId) {
        return res.status(403).json({ message: "Access denied: Not the owner" });
      }
      req.authenticatedUser = user;
      next();
    } catch (error) {
      console.error("Error checking ownership:", error);
      res.status(500).json({ message: "Failed to authorize request" });
    }
  };
};
var requireManufacturer = async (req, res, next) => {
  try {
    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const manufacturer = await storage.getManufacturerByUserId(userId);
    if (!manufacturer) {
      return res.status(403).json({ message: "Access denied: Manufacturer profile required" });
    }
    req.manufacturer = manufacturer;
    next();
  } catch (error) {
    console.error("Error checking manufacturer:", error);
    res.status(500).json({ message: "Failed to authorize request" });
  }
};
var requireBrand = async (req, res, next) => {
  try {
    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    const brand = await storage.getBrandByUserId(userId);
    if (!brand) {
      return res.status(403).json({ message: "Access denied: Brand profile required" });
    }
    req.brand = brand;
    next();
  } catch (error) {
    console.error("Error checking brand:", error);
    res.status(500).json({ message: "Failed to authorize request" });
  }
};

// server/objectStorage.ts
import fs2 from "fs";
import path from "path";
import { randomUUID as randomUUID2 } from "crypto";

// server/objectAcl.ts
import fs from "fs";
async function setObjectAclPolicy(objectFilePath, aclPolicy) {
  if (!fs.existsSync(objectFilePath)) {
    throw new Error(`Object not found: ${objectFilePath}`);
  }
  const metaPath = `${objectFilePath}.acl.json`;
  await fs.promises.writeFile(metaPath, JSON.stringify(aclPolicy, null, 2), "utf-8");
}
async function getObjectAclPolicy(objectFilePath) {
  try {
    const metaPath = `${objectFilePath}.acl.json`;
    const content = await fs.promises.readFile(metaPath, "utf-8");
    return JSON.parse(content);
  } catch {
    return null;
  }
}
async function canAccessObject({
  userId,
  objectFilePath,
  requestedPermission
}) {
  if (!fs.existsSync(objectFilePath)) return false;
  const aclPolicy = await getObjectAclPolicy(objectFilePath);
  if (!aclPolicy) {
    return requestedPermission === "read" /* READ */;
  }
  if (aclPolicy.visibility === "public" && requestedPermission === "read" /* READ */) {
    return true;
  }
  if (!userId) {
    return false;
  }
  if (aclPolicy.owner === userId) {
    return true;
  }
  if (aclPolicy.allowedUsers && aclPolicy.allowedUsers.includes(userId)) {
    return requestedPermission === "read" /* READ */;
  }
  return false;
}

// server/objectStorage.ts
var ObjectNotFoundError = class _ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
    Object.setPrototypeOf(this, _ObjectNotFoundError.prototype);
  }
};
var ObjectStorageService = class {
  constructor() {
  }
  getPublicObjectSearchPaths() {
    const defaultDir = path.resolve(process.cwd(), "public_objects");
    const pathsStr = process.env.PUBLIC_OBJECT_SEARCH_PATHS || defaultDir;
    const paths = Array.from(
      new Set(
        pathsStr.split(",").map((p) => p.trim()).filter((p) => p.length > 0).map((p) => path.resolve(process.cwd(), p))
      )
    );
    for (const p of paths) {
      if (!fs2.existsSync(p)) {
        fs2.mkdirSync(p, { recursive: true });
      }
    }
    return paths;
  }
  getPrivateObjectDir() {
    const defaultDir = path.resolve(process.cwd(), "private_objects");
    const dir = process.env.PRIVATE_OBJECT_DIR || defaultDir;
    const abs = path.resolve(process.cwd(), dir);
    if (!fs2.existsSync(abs)) {
      fs2.mkdirSync(abs, { recursive: true });
    }
    return abs;
  }
  async searchPublicObject(filePath) {
    for (const searchPath of this.getPublicObjectSearchPaths()) {
      const fullPath = path.resolve(searchPath, filePath);
      if (fs2.existsSync(fullPath) && fs2.statSync(fullPath).isFile()) {
        return { absolutePath: fullPath };
      }
    }
    return null;
  }
  async downloadObject(file, res, cacheTtlSec = 3600) {
    try {
      const aclPolicy = await getObjectAclPolicy(file.absolutePath);
      const isPublic = aclPolicy?.visibility === "public";
      const stat = fs2.statSync(file.absolutePath);
      res.set({
        "Content-Type": getContentType(file.absolutePath),
        "Content-Length": String(stat.size),
        "Cache-Control": `${isPublic ? "public" : "private"}, max-age=${cacheTtlSec}`
      });
      const stream = fs2.createReadStream(file.absolutePath);
      stream.on("error", (err) => {
        console.error("Stream error:", err);
        if (!res.headersSent) {
          res.status(500).json({ error: "Error streaming file" });
        }
      });
      stream.pipe(res);
    } catch (error) {
      console.error("Error downloading file:", error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Error downloading file" });
      }
    }
  }
  async getObjectEntityUploadURL() {
    const privateObjectDir = this.getPrivateObjectDir();
    const objectId = randomUUID2();
    const uploadDir = path.join(privateObjectDir, "uploads");
    if (!fs2.existsSync(uploadDir)) {
      fs2.mkdirSync(uploadDir, { recursive: true });
    }
    const targetPath = path.join(uploadDir, objectId);
    const uploadUrl = `/api/objects/upload/${objectId}`;
    const publicUrl = `/objects/uploads/${objectId}`;
    return { uploadUrl, publicUrl };
  }
  async getObjectEntityFile(objectPath) {
    if (!objectPath.startsWith("/objects/")) {
      throw new ObjectNotFoundError();
    }
    const parts = objectPath.slice(1).split("/");
    if (parts.length < 2) {
      throw new ObjectNotFoundError();
    }
    const entityId = parts.slice(1).join("/");
    const entityDir = this.getPrivateObjectDir();
    const objectEntityPath = path.join(entityDir, entityId);
    if (!fs2.existsSync(objectEntityPath) || !fs2.statSync(objectEntityPath).isFile()) {
      throw new ObjectNotFoundError();
    }
    return { absolutePath: objectEntityPath };
  }
  normalizeObjectEntityPath(rawPath) {
    const privateDir = this.getPrivateObjectDir();
    const abs = path.resolve(rawPath);
    if (!abs.startsWith(privateDir)) {
      return rawPath;
    }
    const entityId = path.relative(privateDir, abs).replace(/\\/g, "/");
    return `/objects/${entityId}`;
  }
  async trySetObjectEntityAclPolicy(rawPath, aclPolicy) {
    const normalizedPath = this.normalizeObjectEntityPath(rawPath);
    if (!normalizedPath.startsWith("/")) {
      return normalizedPath;
    }
    const objectFile = await this.getObjectEntityFile(normalizedPath);
    await setObjectAclPolicy(objectFile.absolutePath, aclPolicy);
    return normalizedPath;
  }
  async canAccessObjectEntity({
    userId,
    objectFile,
    requestedPermission
  }) {
    return canAccessObject({
      userId,
      objectFilePath: objectFile.absolutePath,
      requestedPermission: requestedPermission ?? "read" /* READ */
    });
  }
};
function getContentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  switch (ext) {
    case ".png":
      return "image/png";
    case ".jpg":
    case ".jpeg":
      return "image/jpeg";
    case ".gif":
      return "image/gif";
    case ".svg":
      return "image/svg+xml";
    case ".pdf":
      return "application/pdf";
    case ".txt":
      return "text/plain";
    case ".json":
      return "application/json";
    default:
      return "application/octet-stream";
  }
}

// server/ai.ts
var OLLAMA_BASE_URL = process.env.AI_OLLAMA_BASE_URL || "http://localhost:11434";
var OLLAMA_MODEL = process.env.AI_OLLAMA_MODEL || "llama3.1";
var JAMBOT_SYSTEM_PROMPT = `You are JamBot, an AI assistant specialized in helping users navigate Jamaica's manufacturing and agro-processing industries. You have deep knowledge about:

1. Manufacturing processes and certifications (HACCP, GMP, ISO, Organic, FDA)
2. Import/export procedures for Jamaica
3. Business registration and regulatory compliance
4. Production planning and cost analysis
5. Quality control and food safety standards
6. Supply chain management
7. Connecting brands with manufacturers

Your role is to:
- Provide accurate, helpful information about manufacturing in Jamaica
- Guide users through certification processes
- Help with cost analysis and production planning
- Explain import/export requirements
- Suggest solutions for manufacturing challenges
- Recommend next steps for businesses

Always be professional, encouraging, and supportive. If you don't know something specific, acknowledge it and suggest where they might find the information.`;
async function getChatbotResponse(message, conversationHistory) {
  try {
    const messages2 = [
      { role: "system", content: JAMBOT_SYSTEM_PROMPT }
    ];
    if (conversationHistory && conversationHistory.length > 0) {
      messages2.push(...conversationHistory);
    }
    messages2.push({ role: "user", content: message });
    const resp = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        messages: messages2,
        options: { temperature: 0.7 },
        stream: false
      })
    });
    if (!resp.ok) {
      const text2 = await resp.text();
      throw new Error(`Ollama error: ${resp.status} ${text2}`);
    }
    const json = await resp.json();
    const content = json?.message?.content || "";
    return content || "I apologize, but I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("Error generating chatbot response:", error);
    throw new Error("Failed to generate response from AI assistant");
  }
}

// server/routes.ts
init_schema();
async function registerRoutes(app2) {
  await setupAuth(app2);
  app2.get("/api/auth/user", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  app2.get("/api/profile/manufacturer", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const manufacturer = await storage.getManufacturerByUserId(userId);
      if (!manufacturer) {
        return res.status(404).json({ message: "Manufacturer profile not found" });
      }
      res.json(manufacturer);
    } catch (error) {
      console.error("Error fetching manufacturer profile:", error);
      res.status(500).json({ message: "Failed to fetch manufacturer profile" });
    }
  });
  app2.get("/api/profile/brand", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const brand = await storage.getBrandByUserId(userId);
      if (!brand) {
        return res.status(404).json({ message: "Brand profile not found" });
      }
      res.json(brand);
    } catch (error) {
      console.error("Error fetching brand profile:", error);
      res.status(500).json({ message: "Failed to fetch brand profile" });
    }
  });
  app2.get("/api/manufacturers", async (req, res) => {
    try {
      const filters = req.query;
      const manufacturers2 = await storage.searchManufacturers(filters);
      res.json(manufacturers2);
    } catch (error) {
      console.error("Error fetching manufacturers:", error);
      res.status(500).json({ message: "Failed to fetch manufacturers" });
    }
  });
  app2.get("/api/manufacturers/:id", async (req, res) => {
    try {
      const manufacturer = await storage.getManufacturer(req.params.id);
      if (!manufacturer) {
        return res.status(404).json({ message: "Manufacturer not found" });
      }
      res.json(manufacturer);
    } catch (error) {
      console.error("Error fetching manufacturer:", error);
      res.status(500).json({ message: "Failed to fetch manufacturer" });
    }
  });
  app2.post("/api/manufacturers", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertManufacturerSchema.parse({ ...req.body, userId });
      const manufacturer = await storage.createManufacturer(validatedData);
      res.status(201).json(manufacturer);
    } catch (error) {
      console.error("Error creating manufacturer:", error);
      res.status(400).json({ message: error.message || "Failed to create manufacturer" });
    }
  });
  const updateManufacturerHandler = async (req, res) => {
    try {
      const validatedData = updateManufacturerSchema.partial().parse(req.body);
      const updatedManufacturer = await storage.updateManufacturer(req.params.id, validatedData);
      if (!updatedManufacturer) {
        return res.status(404).json({ message: "Manufacturer not found" });
      }
      res.json(updatedManufacturer);
    } catch (error) {
      console.error("Error updating manufacturer:", error);
      res.status(400).json({ message: error.message || "Failed to update manufacturer" });
    }
  };
  const manufacturerOwnership = requireOwnership(async (req) => {
    const manufacturer = await storage.getManufacturer(req.params.id);
    return manufacturer?.userId;
  });
  app2.put("/api/manufacturers/:id", isAuthenticated, manufacturerOwnership, updateManufacturerHandler);
  app2.patch("/api/manufacturers/:id", isAuthenticated, manufacturerOwnership, updateManufacturerHandler);
  app2.get("/api/manufacturers/:id/portfolio", async (req, res) => {
    try {
      const portfolioItems2 = await storage.getPortfolioItemsByManufacturer(req.params.id);
      res.json(portfolioItems2);
    } catch (error) {
      console.error("Error fetching portfolio:", error);
      res.status(500).json({ message: "Failed to fetch portfolio" });
    }
  });
  app2.get("/api/manufacturers/:id/certifications", async (req, res) => {
    try {
      const certifications2 = await storage.getCertificationsByManufacturer(req.params.id);
      res.json(certifications2);
    } catch (error) {
      console.error("Error fetching certifications:", error);
      res.status(500).json({ message: "Failed to fetch certifications" });
    }
  });
  app2.get("/api/manufacturers/:id/reviews", async (req, res) => {
    try {
      const reviews2 = await storage.getReviewsByManufacturer(req.params.id);
      res.json(reviews2);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });
  app2.get("/api/brands/:id", async (req, res) => {
    try {
      const brand = await storage.getBrand(req.params.id);
      if (!brand) {
        return res.status(404).json({ message: "Brand not found" });
      }
      res.json(brand);
    } catch (error) {
      console.error("Error fetching brand:", error);
      res.status(500).json({ message: "Failed to fetch brand" });
    }
  });
  app2.post("/api/brands", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const validatedData = insertBrandSchema.parse({ ...req.body, userId });
      const brand = await storage.createBrand(validatedData);
      res.status(201).json(brand);
    } catch (error) {
      console.error("Error creating brand:", error);
      res.status(400).json({ message: error.message || "Failed to create brand" });
    }
  });
  const updateBrandHandler = async (req, res) => {
    try {
      const validatedData = updateBrandSchema.partial().parse(req.body);
      const updatedBrand = await storage.updateBrand(req.params.id, validatedData);
      if (!updatedBrand) {
        return res.status(404).json({ message: "Brand not found" });
      }
      res.json(updatedBrand);
    } catch (error) {
      console.error("Error updating brand:", error);
      res.status(400).json({ message: error.message || "Failed to update brand" });
    }
  };
  const brandOwnership = requireOwnership(async (req) => {
    const brand = await storage.getBrand(req.params.id);
    return brand?.userId;
  });
  app2.put("/api/brands/:id", isAuthenticated, brandOwnership, updateBrandHandler);
  app2.patch("/api/brands/:id", isAuthenticated, brandOwnership, updateBrandHandler);
  app2.get("/api/rfqs", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (user?.role === "brand") {
        const brand = await storage.getBrandByUserId(userId);
        if (brand) {
          const rfqs2 = await storage.getRfqsByBrand(brand.id);
          return res.json(rfqs2);
        }
      } else if (user?.role === "manufacturer") {
        const rfqs2 = await storage.getActiveRfqs();
        return res.json(rfqs2);
      }
      res.json([]);
    } catch (error) {
      console.error("Error fetching RFQs:", error);
      res.status(500).json({ message: "Failed to fetch RFQs" });
    }
  });
  app2.get("/api/rfqs/:id", async (req, res) => {
    try {
      const rfq = await storage.getRfq(req.params.id);
      if (!rfq) {
        return res.status(404).json({ message: "RFQ not found" });
      }
      res.json(rfq);
    } catch (error) {
      console.error("Error fetching RFQ:", error);
      res.status(500).json({ message: "Failed to fetch RFQ" });
    }
  });
  app2.post("/api/rfqs", isAuthenticated, requireBrand, async (req, res) => {
    try {
      const brand = req.brand;
      const validatedData = insertRfqSchema.parse({ ...req.body, brandId: brand.id });
      const rfq = await storage.createRfq(validatedData);
      res.status(201).json(rfq);
    } catch (error) {
      console.error("Error creating RFQ:", error);
      res.status(400).json({ message: error.message || "Failed to create RFQ" });
    }
  });
  const updateRfqHandler = async (req, res) => {
    try {
      const validatedData = updateRfqSchema.partial().parse(req.body);
      const updatedRfq = await storage.updateRfq(req.params.id, validatedData);
      if (!updatedRfq) {
        return res.status(404).json({ message: "RFQ not found" });
      }
      res.json(updatedRfq);
    } catch (error) {
      console.error("Error updating RFQ:", error);
      res.status(400).json({ message: error.message || "Failed to update RFQ" });
    }
  };
  const rfqOwnership = requireOwnership(async (req) => {
    const rfq = await storage.getRfq(req.params.id);
    if (!rfq) return void 0;
    const brand = await storage.getBrand(rfq.brandId);
    return brand?.userId;
  });
  app2.put("/api/rfqs/:id", isAuthenticated, rfqOwnership, updateRfqHandler);
  app2.patch("/api/rfqs/:id", isAuthenticated, rfqOwnership, updateRfqHandler);
  app2.delete("/api/rfqs/:id", isAuthenticated, requireOwnership(async (req) => {
    const rfq = await storage.getRfq(req.params.id);
    if (!rfq) return void 0;
    const brand = await storage.getBrand(rfq.brandId);
    return brand?.userId;
  }), async (req, res) => {
    try {
      const deleted = await storage.deleteRfq(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "RFQ not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting RFQ:", error);
      res.status(500).json({ message: "Failed to delete RFQ" });
    }
  });
  app2.get("/api/rfqs/:id/responses", async (req, res) => {
    try {
      const responses = await storage.getRfqResponsesByRfq(req.params.id);
      res.json(responses);
    } catch (error) {
      console.error("Error fetching RFQ responses:", error);
      res.status(500).json({ message: "Failed to fetch RFQ responses" });
    }
  });
  app2.post("/api/rfqs/:id/responses", isAuthenticated, requireManufacturer, async (req, res) => {
    try {
      const manufacturer = req.manufacturer;
      const validatedData = insertRfqResponseSchema.parse({
        ...req.body,
        rfqId: req.params.id,
        manufacturerId: manufacturer.id
      });
      const response = await storage.createRfqResponse(validatedData);
      res.status(201).json(response);
    } catch (error) {
      console.error("Error creating RFQ response:", error);
      res.status(400).json({ message: error.message || "Failed to create RFQ response" });
    }
  });
  app2.get("/api/creators", async (req, res) => {
    try {
      const availableForHire = req.query.availableForHire === "true" ? true : req.query.availableForHire === "false" ? false : void 0;
      const creators2 = await storage.getCreators({ availableForHire });
      res.json(creators2);
    } catch (error) {
      console.error("Error fetching creators:", error);
      res.status(500).json({ message: "Failed to fetch creators" });
    }
  });
  app2.get("/api/creators/:id", async (req, res) => {
    try {
      const creator = await storage.getCreator(req.params.id);
      if (!creator) {
        return res.status(404).json({ message: "Creator not found" });
      }
      res.json(creator);
    } catch (error) {
      console.error("Error fetching creator:", error);
      res.status(500).json({ message: "Failed to fetch creator" });
    }
  });
  app2.get("/api/designers", async (req, res) => {
    try {
      const availableForHire = req.query.availableForHire === "true" ? true : req.query.availableForHire === "false" ? false : void 0;
      const designers2 = await storage.getDesigners({ availableForHire });
      res.json(designers2);
    } catch (error) {
      console.error("Error fetching designers:", error);
      res.status(500).json({ message: "Failed to fetch designers" });
    }
  });
  app2.get("/api/designers/:id", async (req, res) => {
    try {
      const designer = await storage.getDesigner(req.params.id);
      if (!designer) {
        return res.status(404).json({ message: "Designer not found" });
      }
      res.json(designer);
    } catch (error) {
      console.error("Error fetching designer:", error);
      res.status(500).json({ message: "Failed to fetch designer" });
    }
  });
  app2.get("/api/finance/lenders", async (req, res) => {
    try {
      const lenders = await storage.getFinancialInstitutions();
      res.json(lenders);
    } catch (error) {
      console.error("Error fetching lenders:", error);
      res.status(500).json({ message: "Failed to fetch lenders" });
    }
  });
  app2.get("/api/finance/lenders/:id", async (req, res) => {
    try {
      const lender = await storage.getFinancialInstitution(req.params.id);
      if (!lender) {
        return res.status(404).json({ message: "Lender not found" });
      }
      res.json(lender);
    } catch (error) {
      console.error("Error fetching lender:", error);
      res.status(500).json({ message: "Failed to fetch lender" });
    }
  });
  app2.get("/api/finance/lenders/:id/loan-products", async (req, res) => {
    try {
      const loanProducts2 = await storage.getLoanProductsByInstitution(req.params.id);
      res.json(loanProducts2);
    } catch (error) {
      console.error("Error fetching loan products:", error);
      res.status(500).json({ message: "Failed to fetch loan products" });
    }
  });
  app2.post("/api/finance/loan-applications", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      const validatedData = {
        ...req.body,
        applicantId: userId,
        applicantType: user.role
      };
      const application = await storage.createLoanApplication(validatedData);
      res.status(201).json(application);
    } catch (error) {
      console.error("Error creating loan application:", error);
      res.status(400).json({ message: error.message || "Failed to create loan application" });
    }
  });
  app2.get("/api/finance/loan-applications", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const applications = await storage.getLoanApplicationsByApplicant(userId);
      res.json(applications);
    } catch (error) {
      console.error("Error fetching loan applications:", error);
      res.status(500).json({ message: "Failed to fetch loan applications" });
    }
  });
  app2.get("/api/projects", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (user?.role === "brand") {
        const brand = await storage.getBrandByUserId(userId);
        if (brand) {
          const projects2 = await storage.getProjectsByBrand(brand.id);
          return res.json(projects2);
        }
      } else if (user?.role === "manufacturer") {
        const manufacturer = await storage.getManufacturerByUserId(userId);
        if (manufacturer) {
          const projects2 = await storage.getProjectsByManufacturer(manufacturer.id);
          return res.json(projects2);
        }
      }
      res.json([]);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });
  app2.get("/api/projects/:id", isAuthenticated, async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      console.error("Error fetching project:", error);
      res.status(500).json({ message: "Failed to fetch project" });
    }
  });
  app2.post("/api/projects", isAuthenticated, requireBrand, async (req, res) => {
    try {
      const brand = req.brand;
      const userId = req.user.claims.sub;
      const validatedData = insertProjectSchema.parse({
        ...req.body,
        brandId: brand.id
        // Override with authenticated user's brand
      });
      const project = await storage.createProject(validatedData);
      res.status(201).json(project);
    } catch (error) {
      console.error("Error creating project:", error);
      res.status(400).json({ message: error.message || "Failed to create project" });
    }
  });
  const updateProjectHandler = async (req, res) => {
    try {
      const validatedData = updateProjectSchema.partial().parse(req.body);
      const updatedProject = await storage.updateProject(req.params.id, validatedData);
      if (!updatedProject) {
        return res.status(404).json({ message: "Project not found" });
      }
      res.json(updatedProject);
    } catch (error) {
      console.error("Error updating project:", error);
      res.status(400).json({ message: error.message || "Failed to update project" });
    }
  };
  const projectOwnership = requireOwnership(async (req) => {
    const project = await storage.getProject(req.params.id);
    if (!project) return void 0;
    const brand = await storage.getBrand(project.brandId);
    return brand?.userId;
  });
  app2.put("/api/projects/:id", isAuthenticated, projectOwnership, updateProjectHandler);
  app2.patch("/api/projects/:id", isAuthenticated, projectOwnership, updateProjectHandler);
  app2.get("/api/messages/threads", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const threads = await storage.getMessageThreads(userId);
      res.json(threads);
    } catch (error) {
      console.error("Error fetching message threads:", error);
      res.status(500).json({ message: "Failed to fetch message threads" });
    }
  });
  app2.get("/api/messages/:userId", isAuthenticated, async (req, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const otherUserId = req.params.userId;
      const messages2 = await storage.getMessagesBetweenUsers(currentUserId, otherUserId);
      res.json(messages2);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  app2.post("/api/messages", isAuthenticated, async (req, res) => {
    try {
      const senderId = req.user.claims.sub;
      const validatedData = insertMessageSchema.parse({ ...req.body, senderId });
      const message = await storage.createMessage(validatedData);
      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(400).json({ message: error.message || "Failed to create message" });
    }
  });
  app2.put("/api/messages/:id/read", isAuthenticated, async (req, res) => {
    try {
      const marked = await storage.markMessageAsRead(req.params.id);
      if (!marked) {
        return res.status(404).json({ message: "Message not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ message: "Failed to mark message as read" });
    }
  });
  app2.post("/api/reviews", isAuthenticated, async (req, res) => {
    try {
      const reviewerId = req.user.claims.sub;
      const validatedData = insertReviewSchema.parse({ ...req.body, reviewerId });
      const review = await storage.createReview(validatedData);
      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(400).json({ message: error.message || "Failed to create review" });
    }
  });
  app2.put("/api/reviews/:id/response", isAuthenticated, requireOwnership(async (req) => {
    const review = await storage.getReview(req.params.id);
    if (!review) return void 0;
    const manufacturer = await storage.getManufacturer(review.manufacturerId);
    return manufacturer?.userId;
  }), async (req, res) => {
    try {
      const { response } = req.body;
      if (!response || typeof response !== "string") {
        return res.status(400).json({ message: "Response text is required" });
      }
      const updatedReview = await storage.updateReviewResponse(req.params.id, response);
      if (!updatedReview) {
        return res.status(404).json({ message: "Review not found" });
      }
      res.json(updatedReview);
    } catch (error) {
      console.error("Error updating review response:", error);
      res.status(500).json({ message: "Failed to update review response" });
    }
  });
  app2.post("/api/certifications", isAuthenticated, requireManufacturer, async (req, res) => {
    try {
      const manufacturer = req.manufacturer;
      const validatedData = insertCertificationSchema.parse({
        ...req.body,
        manufacturerId: manufacturer.id
        // Override with authenticated user's manufacturer
      });
      const certification = await storage.createCertification(validatedData);
      res.status(201).json(certification);
    } catch (error) {
      console.error("Error creating certification:", error);
      res.status(400).json({ message: error.message || "Failed to create certification" });
    }
  });
  app2.post("/api/portfolio", isAuthenticated, requireManufacturer, async (req, res) => {
    try {
      const manufacturer = req.manufacturer;
      const validatedData = insertPortfolioItemSchema.parse({
        ...req.body,
        manufacturerId: manufacturer.id
        // Override with authenticated user's manufacturer
      });
      const item = await storage.createPortfolioItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      console.error("Error creating portfolio item:", error);
      res.status(400).json({ message: error.message || "Failed to create portfolio item" });
    }
  });
  app2.get("/api/verifications", isAuthenticated, async (req, res) => {
    try {
      const verifications = await storage.getPendingVerifications();
      res.json(verifications);
    } catch (error) {
      console.error("Error fetching verifications:", error);
      res.status(500).json({ message: "Failed to fetch verifications" });
    }
  });
  app2.post("/api/verifications", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertVerificationRequestSchema.parse(req.body);
      const request = await storage.createVerificationRequest(validatedData);
      res.status(201).json(request);
    } catch (error) {
      console.error("Error creating verification request:", error);
      res.status(400).json({ message: error.message || "Failed to create verification request" });
    }
  });
  app2.put("/api/verifications/:id/approve", isAuthenticated, requireRole(["admin"]), async (req, res) => {
    try {
      const reviewedBy = req.user.claims.sub;
      const { notes } = req.body;
      const updated = await storage.updateVerificationStatus(req.params.id, "approved", reviewedBy, notes);
      if (!updated) {
        return res.status(404).json({ message: "Verification request not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error approving verification:", error);
      res.status(500).json({ message: "Failed to approve verification" });
    }
  });
  app2.put("/api/verifications/:id/reject", isAuthenticated, requireRole(["admin"]), async (req, res) => {
    try {
      const reviewedBy = req.user.claims.sub;
      const { notes } = req.body;
      const updated = await storage.updateVerificationStatus(req.params.id, "rejected", reviewedBy, notes);
      if (!updated) {
        return res.status(404).json({ message: "Verification request not found" });
      }
      res.json(updated);
    } catch (error) {
      console.error("Error rejecting verification:", error);
      res.status(500).json({ message: "Failed to reject verification" });
    }
  });
  app2.get("/api/financing/leads", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (user?.role === "financial_institution") {
        const leads = await storage.getFinancingLeadsByInstitution(userId);
        return res.json(leads);
      }
      res.json([]);
    } catch (error) {
      console.error("Error fetching financing leads:", error);
      res.status(500).json({ message: "Failed to fetch financing leads" });
    }
  });
  app2.post("/api/financing/leads", isAuthenticated, async (req, res) => {
    try {
      const applicantId = req.user.claims.sub;
      const validatedData = insertFinancingLeadSchema.parse({ ...req.body, applicantId });
      const lead = await storage.createFinancingLead(validatedData);
      res.status(201).json(lead);
    } catch (error) {
      console.error("Error creating financing lead:", error);
      res.status(400).json({ message: error.message || "Failed to create financing lead" });
    }
  });
  app2.put("/api/financing/leads/:id", isAuthenticated, requireRole(["financial_institution", "admin"]), async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = req.authenticatedUser;
      const { status } = req.body;
      if (!status || typeof status !== "string") {
        return res.status(400).json({ message: "Status is required" });
      }
      const lead = await storage.getFinancingLead(req.params.id);
      if (!lead) {
        return res.status(404).json({ message: "Financing lead not found" });
      }
      if (user.role !== "admin" && lead.institutionId !== userId) {
        return res.status(403).json({ message: "Access denied: Not your financing lead" });
      }
      const updated = await storage.updateFinancingLeadStatus(req.params.id, status);
      res.json(updated);
    } catch (error) {
      console.error("Error updating financing lead:", error);
      res.status(500).json({ message: "Failed to update financing lead" });
    }
  });
  app2.get("/api/resources", async (req, res) => {
    try {
      const { category } = req.query;
      const resources2 = category ? await storage.getResourcesByCategory(category) : await storage.getResources();
      res.json(resources2);
    } catch (error) {
      console.error("Error fetching resources:", error);
      res.status(500).json({ message: "Failed to fetch resources" });
    }
  });
  app2.post("/api/resources/:id/view", async (req, res) => {
    try {
      await storage.incrementResourceView(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error incrementing resource view:", error);
      res.status(500).json({ message: "Failed to increment resource view" });
    }
  });
  app2.post("/api/resources/:id/download", async (req, res) => {
    try {
      await storage.incrementResourceDownload(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error incrementing resource download:", error);
      res.status(500).json({ message: "Failed to increment resource download" });
    }
  });
  app2.get("/api/notifications", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications2 = await storage.getNotificationsByUser(userId);
      res.json(notifications2);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });
  app2.put("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    try {
      const marked = await storage.markNotificationAsRead(req.params.id);
      if (!marked) {
        return res.status(404).json({ message: "Notification not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });
  app2.get("/public-objects/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    const objectStorageService = new ObjectStorageService();
    try {
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      objectStorageService.downloadObject(file, res);
    } catch (error) {
      console.error("Error searching for public object:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });
  app2.get("/objects/:objectPath(*)", isAuthenticated, async (req, res) => {
    const userId = req.user?.claims?.sub;
    const objectStorageService = new ObjectStorageService();
    try {
      const objectFile = await objectStorageService.getObjectEntityFile(req.path);
      const canAccess = await objectStorageService.canAccessObjectEntity({
        objectFile,
        userId,
        requestedPermission: "read" /* READ */
      });
      if (!canAccess) {
        return res.sendStatus(401);
      }
      objectStorageService.downloadObject(objectFile, res);
    } catch (error) {
      console.error("Error checking object access:", error);
      if (error instanceof ObjectNotFoundError) {
        return res.sendStatus(404);
      }
      return res.sendStatus(500);
    }
  });
  app2.post("/api/objects/upload", isAuthenticated, async (req, res) => {
    const objectStorageService = new ObjectStorageService();
    try {
      const { uploadUrl, publicUrl } = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadUrl, publicUrl });
    } catch (error) {
      console.error("Error getting upload URL:", error);
      res.status(500).json({ error: "Failed to get upload URL" });
    }
  });
  app2.put("/api/objects/upload/:id", isAuthenticated, async (req, res) => {
    try {
      const objectStorageService = new ObjectStorageService();
      const privateDir = objectStorageService.getPrivateObjectDir();
      const uploadDir = __require("path").join(privateDir, "uploads");
      if (!__require("fs").existsSync(uploadDir)) {
        __require("fs").mkdirSync(uploadDir, { recursive: true });
      }
      const targetPath = __require("path").join(uploadDir, req.params.id);
      const writeStream = __require("fs").createWriteStream(targetPath);
      req.pipe(writeStream);
      writeStream.on("finish", () => {
        res.status(201).json({ path: `/objects/uploads/${req.params.id}` });
      });
      writeStream.on("error", (err) => {
        console.error("Upload error:", err);
        res.status(500).json({ error: "Failed to upload file" });
      });
    } catch (error) {
      console.error("Error handling upload:", error);
      res.status(500).json({ error: "Failed to upload file" });
    }
  });
  app2.post("/api/chat", isAuthenticated, async (req, res) => {
    try {
      const { message, conversationHistory } = req.body;
      if (!message || typeof message !== "string") {
        return res.status(400).json({ message: "Message is required" });
      }
      const response = await getChatbotResponse(message, conversationHistory);
      res.json({ response });
    } catch (error) {
      console.error("Error generating chat response:", error);
      res.status(500).json({ message: "Failed to generate response" });
    }
  });
  app2.get("/api/courses", async (req, res) => {
    try {
      const { category } = req.query;
      const courses2 = await storage.getCourses(category);
      res.json(courses2);
    } catch (error) {
      console.error("Error fetching courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });
  app2.get("/api/courses/:id", async (req, res) => {
    try {
      const courseDetails = await storage.getCourseWithModulesAndLessons(req.params.id);
      if (!courseDetails) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(courseDetails);
    } catch (error) {
      console.error("Error fetching course details:", error);
      res.status(500).json({ message: "Failed to fetch course details" });
    }
  });
  app2.post("/api/courses/:id/enroll", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const courseId = req.params.id;
      const enrollment = await storage.enrollInCourse(userId, courseId);
      res.status(201).json(enrollment);
    } catch (error) {
      console.error("Error enrolling in course:", error);
      res.status(400).json({ message: error.message || "Failed to enroll in course" });
    }
  });
  app2.get("/api/courses/:id/progress", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const courseId = req.params.id;
      const progress = await storage.getCourseProgress(userId, courseId);
      res.json(progress);
    } catch (error) {
      console.error("Error fetching course progress:", error);
      res.status(500).json({ message: "Failed to fetch course progress" });
    }
  });
  app2.post("/api/lessons/:id/complete", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const lessonId = req.params.id;
      const progress = await storage.markLessonComplete(userId, lessonId);
      res.json(progress);
    } catch (error) {
      console.error("Error marking lesson complete:", error);
      res.status(400).json({ message: error.message || "Failed to mark lesson complete" });
    }
  });
  app2.get("/api/enrollments", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const enrollments = await storage.getUserEnrollments(userId);
      res.json(enrollments);
    } catch (error) {
      console.error("Error fetching enrollments:", error);
      res.status(500).json({ message: "Failed to fetch enrollments" });
    }
  });
  app2.get("/api/raw-materials", async (req, res) => {
    try {
      const { category } = req.query;
      const materials = await storage.getRawMaterials(category);
      res.json(materials);
    } catch (error) {
      console.error("Error fetching raw materials:", error);
      res.status(500).json({ message: "Failed to fetch raw materials" });
    }
  });
  app2.get("/api/raw-materials/:id", async (req, res) => {
    try {
      const material = await storage.getRawMaterial(req.params.id);
      if (!material) {
        return res.status(404).json({ message: "Raw material not found" });
      }
      res.json(material);
    } catch (error) {
      console.error("Error fetching raw material:", error);
      res.status(500).json({ message: "Failed to fetch raw material" });
    }
  });
  app2.get("/api/raw-materials/:id/suppliers", async (req, res) => {
    try {
      const suppliers = await storage.getRawMaterialSuppliers(req.params.id);
      res.json(suppliers);
    } catch (error) {
      console.error("Error fetching suppliers:", error);
      res.status(500).json({ message: "Failed to fetch suppliers" });
    }
  });
  app2.get("/api/projects/:id/materials", isAuthenticated, async (req, res) => {
    try {
      const materials = await storage.getProjectMaterials(req.params.id);
      res.json(materials);
    } catch (error) {
      console.error("Error fetching project materials:", error);
      res.status(500).json({ message: "Failed to fetch project materials" });
    }
  });
  app2.post("/api/projects/:id/materials", isAuthenticated, async (req, res) => {
    try {
      const projectId = req.params.id;
      const data = insertProjectMaterialSchema.parse({
        ...req.body,
        projectId
      });
      const material = await storage.addMaterialToProject(data);
      res.json(material);
    } catch (error) {
      console.error("Error adding material to project:", error);
      res.status(400).json({ message: error.message || "Failed to add material" });
    }
  });
  app2.patch("/api/project-materials/:id", isAuthenticated, async (req, res) => {
    try {
      const { quantity } = req.body;
      if (!quantity || quantity <= 0) {
        return res.status(400).json({ message: "Valid quantity required" });
      }
      const material = await storage.updateProjectMaterialQuantity(req.params.id, quantity);
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }
      res.json(material);
    } catch (error) {
      console.error("Error updating material quantity:", error);
      res.status(500).json({ message: "Failed to update material quantity" });
    }
  });
  app2.delete("/api/project-materials/:id", isAuthenticated, async (req, res) => {
    try {
      const success = await storage.removeMaterialFromProject(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Material not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing material:", error);
      res.status(500).json({ message: "Failed to remove material" });
    }
  });
  app2.get("/api/projects/:id/materials/cost", isAuthenticated, async (req, res) => {
    try {
      const cost = await storage.getProjectMaterialsCost(req.params.id);
      res.json(cost);
    } catch (error) {
      console.error("Error calculating materials cost:", error);
      res.status(500).json({ message: "Failed to calculate cost" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs3 from "fs";
import path3 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path2 from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      ),
      await import("@replit/vite-plugin-dev-banner").then(
        (m) => m.devBanner()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path2.resolve(import.meta.dirname, "client", "src"),
      "@shared": path2.resolve(import.meta.dirname, "shared"),
      "@assets": path2.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path2.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path2.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path3.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs3.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path3.resolve(import.meta.dirname, "public");
  if (!fs3.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path3.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path4 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path4.startsWith("/api")) {
      let logLine = `${req.method} ${path4} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = parseInt(process.env.PORT || "5000", 10);
  const listenOptions = {
    port,
    host: "0.0.0.0"
  };
  if (process.platform !== "win32") {
    listenOptions.reusePort = true;
  }
  server.listen(listenOptions, () => {
    log(`serving on port ${port}`);
  });
})();
